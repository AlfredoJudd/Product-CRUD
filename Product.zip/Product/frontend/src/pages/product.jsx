import React, { useState, useEffect } from 'react';
import api from '../utils/axios';
import { toast } from 'react-toastify';
import ProductFormCreate from '../components/productForm';
import ProductDelete from '../components/productDelete';

const Products = () => {
    const [product, setProduct] = useState([]);
    const [showForm, setShowForm] = useState(false)
    const [showDelete, setDelete] = useState(false)
    const [selectedProduct, setSelectedProduct] = useState(null);

    const fetchProduct = async () => {
        try {
            const response = await api.get('/');
            console.log(response.data);
            const data = Array.isArray(response.data) ? response.data : response.data.products;
            if (Array.isArray(data)) {
                setProduct(data);
            } else {
                setProduct([]);
            }
        } catch (error) {
            toast.error('Error fetching products');
        }
    }
    useEffect(() => {
        fetchProduct();
    }, []);

    const handleProductAdded = () => {
        fetchProduct();
        setShowForm(false);
        setSelectedProduct(null);
    };

    const handleEdit = (product) => {
        setSelectedProduct(product);
        setShowForm(true);
    };

    const handleDeleteClick = (product) => {
        setSelectedProduct(product);
        setDelete(true);
    }

    const handleDelete = async (productId) => {
        try {
            await api.delete(`/${productId}`);
            toast.success('Product deleted successfully');
            fetchProduct();
            setDelete(false);
            setSelectedProduct(null);
        } catch (error) {
            toast.error('Error deleting product');
        }
    };

    return (
        <div className="flex">
            <div className="flex-grow p-4">
                <h1>Products</h1>
                <button className="btn btn-primary" onClick={() => setShowForm(true)}>Add Product</button>
                {showForm && (
                    <ProductFormCreate
                        show={showForm}
                        onClose={() => setShowForm(false)}
                        onProductAdded={handleProductAdded}
                        productData={selectedProduct}
                    />
                )}
                {showDelete && (
                    <ProductDelete
                        show={showDelete}
                        onClose={() => setDelete(false)}
                        onDelete={() => handleDelete(selectedProduct?._id)}
                        productName={selectedProduct?.name}
                    />
                )}
                <table className="table">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Category</th>
                            <th>Stock</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {product.map((item) => (
                            <tr key={item._id}>
                                <td>{item.name}</td>
                                <td>{item.description}</td>
                                <td>{item.price}</td>
                                <td>{item.category}</td>
                                <td>{item.stock}</td>
                                <td>
                                    <button className="btn btn-primary" onClick={() => handleEdit(item)}>Edit</button>
                                    <button className="btn btn-danger" onClick={() => handleDeleteClick(item)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
export default Products;