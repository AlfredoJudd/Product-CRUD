import React, { useEffect, useState } from 'react';
import api from '../utils/axios';
import { toast } from 'react-toastify';

const ProductForm = ({ show, onClose, onProductAdded, productData }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [price, setPrice] = useState('');
    const [category, setCategory] = useState('');

    useEffect(() => {
        if (productData) {
            setName(productData.name || '');
            setDescription(productData.description || '');
            setPrice(productData.price || '');
            setCategory(productData.category || '');
        }
    }, [productData]);

    const submittionHandler = async (e) => {
        e.preventDefault();
        try {
            const formData = { name, description, price, category };
            let response;
            if (productData && productData._id) {
                response = await api.put(`/${productData._id}`, JSON.stringify(formData), {
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });
                if (response.status === 200) {
                    toast.success('Product updated successfully');
                    onProductAdded();
                    onClose();
                    return;
                }
            } else {
                response = await api.post('/', JSON.stringify(formData), {
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });

                if (response.status === 201) {
                    toast.success('Product created successfully');
                    onProductAdded();
                    onClose();
                } else {
                    toast.error('Failed to create product');
                };
            }
        } catch (error) {
            console.error('Error creating product:', error);
            toast.error('Error creating product');
        }
    }

    const handleClose = () => {
        setName('');
        setDescription('');
        setPrice('');
        setCategory('');
        onClose();
    };

    if (!show) {
        return null;
    }
    return (
        <div className="modal fade show d-block" tabIndex="-1" role="dialog">
            <div className="modal-dialog" role="document">
                <div className="modal-content">
                    <div className="modal-header">
                        <h5 className="modal-title">{productData ? 'Edit Product' : 'Add New Product'}</h5>
                        <button type="button" className="btn-close" onClick={handleClose}></button>
                    </div>
                    <div className="modal-body">
                        <form onSubmit={submittionHandler}>
                            <div className="mb-3">
                                <label className="form-label">Product Name</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    placeholder="Enter product name"
                                    required
                                />
                            </div>
                            <div className="mb-3">
                                <label className="form-label">Product Description</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    value={description}
                                    onChange={(e) => setDescription(e.target.value)}
                                    placeholder="Enter product description"
                                    required
                                />
                            </div>
                            <div className="mb-3">
                                <label className="form-label">Product Price</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    value={price}
                                    onChange={(e) => setPrice(e.target.value)}
                                    placeholder="Enter product price"
                                    required
                                />
                            </div>
                            <div className="mb-3">
                                <label className="form-label">Product Category</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    value={category}
                                    onChange={(e) => setCategory(e.target.value)}
                                    placeholder="Enter product category"
                                    required
                                />
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" onClick={handleClose}>
                                    Cancel
                                </button>
                                <button type="submit" className="btn btn-primary">
                                    Save
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};
export default ProductForm;