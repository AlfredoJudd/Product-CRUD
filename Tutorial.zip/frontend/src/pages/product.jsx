import React, { useState, useEffect } from 'react';
import api from '../utils/axios';
import ProductForm from '../components/productForm';
import ProductDelete from '../components/productDelete';
import { toast } from 'react-toastify';

const Product = () => {
    const [product, setProducts] = useState([]);
    const [showForm, setShowForm] = useState(false);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [showDelete, setDelete] = useState(false);

    const fetchProducts = async () => {
        try {
            const response = await api.get('/');
            const data = Array.isArray(response.data) ? response.data : response.data.product;
            if (Array.isArray(data)) {
                setProducts(data);
            } else {
                setProducts([]);
            }
            setProducts(response.data);
        } catch (error) {
            toast.error('Error fetching products');
        }
    }
    useEffect(() => {
        fetchProducts();
    }, []);

    const handleProductAdded = () => {
        fetchProducts();
        setShowForm(false);
        setSelectedProduct(null);
    }

    const handleEditProduct = (product) => {
        setSelectedProduct(product);
        setShowForm(true);
    }

    const handleDeleteClick = (product) => {
        setSelectedProduct(product);
        setDelete(true);
    }

    const handleDelete = async (productId) => {
        try {
            await api.delete(`/${productId}`);
            toast.success('Product deleted successfully');
            fetchProducts();
            setDelete(false);
            setSelectedProduct(null);
        } catch (error) {
            toast.error('Error deleting product');
        }
    };

    return (
        <div className="flex">
            <div className="flex-grow p-4">
                <h1>Products</h1>
                <button className="btn btn-primary" onClick={() => setShowForm(true)}>Add Product</button>
                {showForm && (
                    <ProductForm
                        show={showForm}
                        onClose={() => setShowForm(false)}
                        onProductAdded={handleProductAdded}
                        productData={selectedProduct}
                    />
                )}
                {showDelete && (
                    <ProductDelete
                        show={showDelete}
                        onClose={() => setDelete(false)}
                        onDelete={() => handleDelete(selectedProduct?._id)}
                        productName={selectedProduct?.name}
                    />
                )}
                <table className="table">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Category</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {product.map((item) => (
                            <tr key={item.id}>
                                <td>{item.name}</td>
                                <td>{item.description}</td>
                                <td>{item.price}</td>
                                <td>{item.category}</td>
                                <td>
                                    <button className="btn btn-primary" onClick={() => handleEditProduct(item)}>Edit</button>
                                    <button className="btn btn-danger" onClick={() => handleDeleteClick(item)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
export default Product;