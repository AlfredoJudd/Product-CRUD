const product = require("../models/product");

exports.createProduct = async (req, res) => {
    try {
        const { name, description, price, category } = req.body;
        const newProduct = new product({
            name,
            description,
            price,
            category,
        });
        await newProduct.save();
        res.status(201).json({ message: "Product created successfully", product: newProduct });
    } catch (error) {
        res.status(500).json({ message: "Error creating product", error });
    }
};

exports.getProducts = async (req, res) => {
    try {
        const products = await product.find();
        res.status(200).json(products);
    } catch (error) {
        res.status(500).json({ message: "Error fetching products", error });
    }
};

exports.getProductById = async (req, res) => {
    try {
        const { id } = req.params;
        const productData = await product.findById(id);
        if (!productData) {
            return res.status(404).json({ message: "Product not found" });
        }
        res.status(200).json(productData);
    } catch (error) {
        res.status(500).json({ message: "Error fetching product", error });
    }
};

exports.updateProduct = async (req, res) => {
    try {
        const { id } = req.params;
        const { name, description, price, category } = req.body;
        const updatedProduct = await product.findByIdAndUpdate(id, {
            name,
            description,
            price,
            category,
        }, { new: true });
        if (!updatedProduct) {
            return res.status(404).json({ message: "Product not found" });
        }
        res.status(200).json({ message: "Product updated successfully", product: updatedProduct });
    }
    catch (error) {
        res.status(500).json({ message: "Error updating product", error });
    }
};

exports.deleteProduct = async (req, res) => {
    try {
        const { id } = req.params;
        const deletedProduct = await product.findByIdAndDelete(id);
        if (!deletedProduct) {
            return res.status(404).json({ message: "Product not found" });
        }
        res.status(200).json({ message: "Product deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error deleting product", error });
    }
};